Import fixtures/seiko_demo_catalog.csv. Do not pre-seed SK-SRPD55-01 images. Run worker process, accept image decision, publish featured SKUs.
