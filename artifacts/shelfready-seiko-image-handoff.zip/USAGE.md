# Seiko image handoff

Downloaded from official Seiko US product pages on 2026-09-14.

Usage: manufacturer-hosted photographs. Official hosting does not grant commercial republication rights.
Isolated ShelfReady demonstration may display them with `demo_storefront_only` captions. Not Seiko-sponsored.

The SRPD55 hero photograph is included here and in replay fixtures while remaining unassigned on the imported supplier row (empty image_filename). Runtime `retrieve_manufacturer_record` must still persist and attach it. Replay vs network retrieval is recorded on evidence.

SK-SRPD53-01 deliberately uses SRPD51K1.png in the supplier CSV as a constructed wrong-variant error.

## Local setup

```
cd services/api && .venv/bin/alembic upgrade head
.venv/bin/python scripts/reset_seiko_demo.py          # dry-run
.venv/bin/python scripts/reset_seiko_demo.py --apply  # new isolated batch
```

Hero SK-SRPD55-01 must have no ProductImage rows after import and before process.
